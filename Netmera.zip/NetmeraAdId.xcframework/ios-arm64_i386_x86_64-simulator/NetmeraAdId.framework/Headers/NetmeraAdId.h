//
//  NetmeraAdId.h
//  NetmeraAdId
//
//  Created by Netmera on 4.10.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for NetmeraAdId.
FOUNDATION_EXPORT double NetmeraAdIdVersionNumber;

//! Project version string for NetmeraAdId.
FOUNDATION_EXPORT const unsigned char NetmeraAdIdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetmeraAdId/PublicHeader.h>

#import <NetmeraAdId/NetmeraAppTrackingTransparancy.h>

