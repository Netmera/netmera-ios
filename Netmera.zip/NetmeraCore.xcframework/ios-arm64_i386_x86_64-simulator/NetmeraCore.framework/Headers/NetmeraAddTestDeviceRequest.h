//
//  NetmeraAddTestDeviceRequest.h
//  
//
//  Created by Yavuz Nuzumlali on 05/02/16.
//
//

#import <NetmeraCore/NetmeraBaseRequest.h>

@interface NetmeraAddTestDeviceRequest : NetmeraBaseRequest

- (instancetype)initWithQueryParameters:(NSString *)params;

@end
