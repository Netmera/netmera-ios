//
//  NetmeraAppConfigRequest.h
//
//
//  Created by Yavuz Nuzumlali on 08/09/15.
//
//

#import <NetmeraCore/NetmeraBaseRequest.h>

@interface NetmeraAppConfigRequest : NetmeraBaseRequest

@end
