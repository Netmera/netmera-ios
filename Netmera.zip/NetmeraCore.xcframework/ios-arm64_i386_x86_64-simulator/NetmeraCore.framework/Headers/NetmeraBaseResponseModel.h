//
//  NetmeraBaseResponseModel.h
//  Pods
//
//  Created by Yavuz Nuzumlali on 06/08/15.
//
//

#import <NetmeraCore/NetmeraBaseModel.h>

@interface NetmeraBaseResponseModel : NetmeraBaseModel

@end
