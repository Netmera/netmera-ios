//
//  NetmeraContentCommentEvent.h
//  Pods
//
//  Created by Yavuz Nuzumlali on 03/09/15.
//
//

#import <NetmeraCore/NetmeraBaseContentEvent.h>

@interface NetmeraContentCommentEvent : NetmeraBaseContentEvent

@end
