//
//  NetmeraDeepLinkAction.h
//
//
//  Created by Yavuz Nuzumlali on 24/11/15.
//
//

#import <NetmeraCore/NetmeraAction.h>

@interface NetmeraDeepLinkAction : NetmeraAction

@property (nonatomic, strong) NSURL *URL;

@end
