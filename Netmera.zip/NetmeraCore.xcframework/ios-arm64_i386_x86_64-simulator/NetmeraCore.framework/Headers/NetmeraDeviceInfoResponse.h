//
//  NetmeraDeviceInfoResponse.h
//  Pods
//
//  Created by inomera on 3.11.2020.
//

#import <NetmeraCore/NetmeraBaseResponseModel.h>

@interface NetmeraDeviceInfoResponse : NetmeraBaseResponseModel

@property (nonatomic, copy) NSString *deeplink;

@end
