//
//  NetmeraDisableAdIdRequest.h
//  Pods
//
//  Created by Netmera on 24.04.2021.
//

#import "NetmeraBaseRequest.h"

@interface NetmeraDisableAdIdRequest : NetmeraBaseRequest

@property (nonatomic, assign) NSInteger source;

@end
