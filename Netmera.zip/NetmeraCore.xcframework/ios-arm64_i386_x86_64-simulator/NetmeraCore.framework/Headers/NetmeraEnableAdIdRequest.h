//
//  NetmeraEnableAdIdRequest.h
//  Pods
//
//  Created by Netmera on 24.04.2021.
//

#import <NetmeraCore/NetmeraBaseRequest.h>

@interface NetmeraEnableAdIdRequest : NetmeraBaseRequest

@property (nonatomic, assign) NSInteger source;

@end
