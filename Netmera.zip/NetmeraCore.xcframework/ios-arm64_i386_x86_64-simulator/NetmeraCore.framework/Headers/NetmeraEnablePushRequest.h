//
//  NetmeraEnablePushRequest.h
//
//
//  Created by Yavuz Nuzumlali on 09/10/15.
//
//

#import <NetmeraCore/NetmeraBaseRequest.h>

@interface NetmeraEnablePushRequest : NetmeraBaseRequest

@property (nonatomic, assign) NSInteger source;

@end
