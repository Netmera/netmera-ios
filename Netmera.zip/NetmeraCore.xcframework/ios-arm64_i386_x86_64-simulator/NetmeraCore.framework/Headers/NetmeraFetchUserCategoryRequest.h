//
//  NetmeraFetchUserCategoryRequest.h
//  NetmeraCore
//
//

#import <NetmeraCore/NetmeraCore.h>

@interface NetmeraFetchUserCategoryRequest : NetmeraBaseRequest

@end
