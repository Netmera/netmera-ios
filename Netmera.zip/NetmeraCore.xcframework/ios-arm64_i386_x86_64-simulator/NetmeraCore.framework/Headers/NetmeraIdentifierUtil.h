//
//  NetmeraIdentifierUtil.h
//
//
//  Created by Yavuz Nuzumlali on 10/09/15.
//
//

#import <Foundation/Foundation.h>

@interface NetmeraIdentifierUtil : NSObject

+ (NSString *)advertisingId;
+ (NSString *)generateShortIdentifier;

@end