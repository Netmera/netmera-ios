//
//  NetmeraIdentifyUserRequest.h
//
//
//  Created by Yavuz Nuzumlali on 13/09/15.
//
//

#import <NetmeraCore/NetmeraUpdateUserRequest.h>

@interface NetmeraIdentifyUserRequest : NetmeraUpdateUserRequest

@end
