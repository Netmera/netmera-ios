//
//  NetmeraIdentifyUserResponse.h
//
//
//  Created by Yavuz Nuzumlali on 13/09/15.
//
//

#import <NetmeraCore/NetmeraBaseResponseModel.h>

@interface NetmeraIdentifyUserResponse : NetmeraBaseResponseModel

@property (nonatomic, copy) NSString *userId;

@end
