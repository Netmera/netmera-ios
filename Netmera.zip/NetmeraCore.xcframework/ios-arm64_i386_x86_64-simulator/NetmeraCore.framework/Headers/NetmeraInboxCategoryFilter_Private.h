//
//  NetmeraInboxCategoryFilter_Private.h
//  Pods
//
//  Created by inomera on 19.02.2020.
//

#import "NetmeraInboxCategoryFilter.h"

@interface NetmeraInboxCategoryFilter ()

@property (nonatomic, strong) NSDictionary *pagingParams;

@end
