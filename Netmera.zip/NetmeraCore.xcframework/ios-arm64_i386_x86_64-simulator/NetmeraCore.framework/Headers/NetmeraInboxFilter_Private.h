//
//  NetmeraInboxFilter_Private.h
//
//
//  Created by Yavuz Nuzumlali on 02/12/15.
//
//

#import "NetmeraInboxFilter.h"

@interface NetmeraInboxFilter ()

@property (nonatomic, strong) NSDictionary *pagingParams;

@end
