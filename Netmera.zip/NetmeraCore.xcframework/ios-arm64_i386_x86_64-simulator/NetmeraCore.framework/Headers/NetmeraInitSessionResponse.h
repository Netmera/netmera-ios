//
//  NetmeraInitSessionResponse.h
//
//
//  Created by Yavuz Nuzumlali on 08/09/15.
//
//

#import <NetmeraCore/NetmeraBaseResponseModel.h>
#import <NetmeraCore/NetmeraAppConfigResponse.h>

@interface NetmeraInitSessionResponse : NetmeraAppConfigResponse

@end
