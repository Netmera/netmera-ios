//
//  NetmeraProductViewEvent.h
//  Pods
//
//  Created by Yavuz Nuzumlali on 03/09/15.
//
//

#import <NetmeraCore/NetmeraBaseProductEvent.h>

@interface NetmeraProductViewEvent : NetmeraBaseProductEvent

@end
