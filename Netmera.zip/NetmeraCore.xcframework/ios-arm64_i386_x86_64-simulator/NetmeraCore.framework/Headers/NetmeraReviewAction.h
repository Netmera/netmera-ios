//
//  NetmeraReviewAction.h
//  Pods
//
//  Created by Netmera on 15.12.2020.
//

#import <NetmeraCore/NetmeraAction.h>

@interface NetmeraReviewAction : NetmeraAction

@end

