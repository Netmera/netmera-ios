//
//  NetmeraSendEventAction.h
//
//
//  Created by Yavuz Nuzumlali on 24/11/15.
//
//

#import <NetmeraCore/NetmeraAction.h>

@interface NetmeraSendEventAction : NetmeraAction

@property (nonatomic, strong) NSDictionary *eventData;

@end
