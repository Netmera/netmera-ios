//
//  NetmeraShareAction.h
//
//
//  Created by Yavuz Nuzumlali on 24/11/15.
//
//

#import <NetmeraCore/NetmeraAction.h>

@interface NetmeraShareAction : NetmeraAction

@end
