//
//  NotificationContentExtension.h
//  NotificationContentExtension
//
//  Created by Netmera on 21.09.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for NotificationContentExtension.
FOUNDATION_EXPORT double NotificationContentExtensionVersionNumber;

//! Project version string for NotificationContentExtension.
FOUNDATION_EXPORT const unsigned char NotificationContentExtensionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NotificationContentExtension/PublicHeader.h>


#import <NotificationContentExtension/NetmeraNotificationContentExtension.h>
