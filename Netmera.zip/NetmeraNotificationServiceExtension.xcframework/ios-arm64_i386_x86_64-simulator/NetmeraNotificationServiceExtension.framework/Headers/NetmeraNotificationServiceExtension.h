//
//  NetmeraNotificationServiceExtension.h
//  
//
//  Created by Yavuz Nuzumlali on 16/11/2016.
//
//

#import <UserNotifications/UserNotifications.h>
#import <CoreServices/CoreServices.h>

#import <NetmeraNotificationServiceExtension/NetmeraNotificationServiceExtension.h>

API_AVAILABLE(ios(10.0))
@interface NetmeraNotificationServiceExtension : UNNotificationServiceExtension

@end
